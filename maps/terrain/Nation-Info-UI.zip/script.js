document.getElementById('game-shortcuts-territories-container').addEventListener('mouseover', () => {
	graphx.setImage('game-shortcuts-territories-header', 'https://github.com/gearshiftstudios/cw-server-res/blob/master/interface/misc/nation_dash_center_blue_glow.png?raw=true')
})
document.getElementById('game-shortcuts-territories-container').addEventListener('mouseout', () => {
	graphx.setImage('game-shortcuts-territories-header', 'https://github.com/gearshiftstudios/cw-server-res/blob/master/interface/misc/nation_dash_center_blue.png?raw=true')
})
document.getElementById('game-shortcuts-colonies-container').addEventListener('mouseover', () => {
	graphx.setImage('game-shortcuts-colonies-header', 'https://github.com/gearshiftstudios/cw-server-res/blob/master/interface/misc/nation_dash_center_blue_glow.png?raw=true')
})
document.getElementById('game-shortcuts-colonies-container').addEventListener('mouseout', () => {
	graphx.setImage('game-shortcuts-colonies-header', 'https://github.com/gearshiftstudios/cw-server-res/blob/master/interface/misc/nation_dash_center_blue.png?raw=true')
})
document.getElementById('game-shortcuts-armies-container').addEventListener('mouseover', () => {
	graphx.setImage('game-shortcuts-armies-header', 'https://github.com/gearshiftstudios/cw-server-res/blob/master/interface/misc/nation_dash_center_blue_glow.png?raw=true')
})
document.getElementById('game-shortcuts-armies-container').addEventListener('mouseout', () => {
	graphx.setImage('game-shortcuts-armies-header', 'https://github.com/gearshiftstudios/cw-server-res/blob/master/interface/misc/nation_dash_center_blue.png?raw=true')
})